<?php
/*
Plugin Name: Bebias Chatbot Widget
Plugin URI:  https://github.com/geganoza/Bebias-chatbot
Description: Embeddable chat widget that connects to the Bebias Vercel backend. Adds a shortcode [bebias_widget] and a simple admin setting to configure the widget URL.
Version:     1.0.0
Author:      Bebias / Martivi
Author URI:  https://bebias.ge
License:     GPLv2 or later
Text Domain: bebias-chatbot-widget
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Bebias_Chatbot_Widget_Plugin {

	const OPTION_NAME = 'bebias_chatbot_widget_url';
	const DEFAULT_URL = 'https://bebias-chatbot-egci.vercel.app/widget';

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'admin_menu' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_shortcode( 'bebias_widget', [ $this, 'shortcode_widget' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
	}

	public function admin_menu() {
		add_options_page(
			'Bebias Chat Widget',
			'Bebias Chat Widget',
			'manage_options',
			'bebias-chat-widget',
			[ $this, 'settings_page' ]
		);
	}

	public function register_settings() {
		register_setting( 'bebias_chat_widget_group', self::OPTION_NAME, [
			'type' => 'string',
			'sanitize_callback' => 'esc_url_raw',
			'default' => self::DEFAULT_URL,
		] );
		add_settings_section( 'bebias_chat_widget_section', 'Widget settings', null, 'bebias-chat-widget' );
		add_settings_field(
			self::OPTION_NAME,
			'Widget URL',
			[ $this, 'field_widget_url' ],
			'bebias-chat-widget',
			'bebias_chat_widget_section'
		);
	}

	public function field_widget_url() {
		$url = esc_attr( get_option( self::OPTION_NAME, self::DEFAULT_URL ) );
		printf(
			'<input type="url" name="%1$s" value="%2$s" style="width:60%%;" /> <p class="description">Full URL of the embeddable widget (iframe src). Example: %3$s</p>',
			esc_attr( self::OPTION_NAME ),
			$url,
			'<code>https://your-vercel-url.vercel.app/widget</code>'
		);
	}

	public function settings_page() {
		?>
		<div class="wrap">
			<h1>Bebias Chat Widget</h1>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'bebias_chat_widget_group' );
				do_settings_sections( 'bebias-chat-widget' );
				submit_button();
				?>
			</form>

			<h2>Usage</h2>
			<p>Place the widget on any page or post using the shortcode:</p>
			<pre>[bebias_widget width="420" height="600"]</pre>

			<p>Or embed as iframe (raw) using the configured Widget URL.</p>

			<h2>Notes</h2>
			<ul>
				<li>The widget communicates with the Vercel backend (same origin as the widget URL). Make sure the Vercel deployment is up to date and the API keys are configured on Vercel.</li>
				<li>If you want the widget to use a different backend, update the Widget URL above to point to the deployed widget path.</li>
			</ul>
		</div>
		<?php
	}

	public function enqueue_assets() {
		wp_register_style( 'bebias-chat-style', plugin_dir_url( __FILE__ ) . 'css/bebias-chat.css', [], '1.0' );
		wp_enqueue_style( 'bebias-chat-style' );
	}

	/**
	 * Shortcode handler: [bebias_widget width="420" height="600"]
	 */
	public function shortcode_widget( $atts = [] ) {
		$atts = shortcode_atts( [
			'width'  => '420',
			'height' => '600',
			'class'  => '',
		], $atts, 'bebias_widget' );

		$widget_url = esc_url( get_option( self::OPTION_NAME, self::DEFAULT_URL ) );

		$width  = esc_attr( $atts['width'] );
		$height = esc_attr( $atts['height'] );
		$cls    = esc_attr( $atts['class'] );

		$iframe = sprintf(
			'<div class="bebias-widget-wrap %1$s" style="max-width:%2$spx;"><iframe src="%3$s" title="Bebias Chat Widget" width="%2$s" height="%4$s" style="border:0;border-radius:12px;overflow:hidden;" allow="clipboard-write;geolocation;microphone;camera" loading="lazy"></iframe></div>',
			$cls,
			$width,
			$widget_url,
			$height
		);

		return $iframe;
	}
}

new Bebias_Chatbot_Widget_Plugin();

/*
Create a small CSS file at wordpress-plugin/css/bebias-chat.css if you want custom styles.
For a single-file upload to WP, you can also include styles inline or instruct users to place widget.html on their site and use an iframe to that URL.
*/
