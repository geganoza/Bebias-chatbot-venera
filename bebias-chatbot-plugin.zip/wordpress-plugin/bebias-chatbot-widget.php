<?php
/**
 * Plugin Name: Bebias Chatbot Widget
 * Description: A simple chat widget for your website.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL2
 * Text Domain: bebias-chatbot
 * Domain Path: /languages
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: bebias-chatbot
 * Domain Path: /languages
 */

/**
 * Add settings page for the plugin
 */
function bebias_chatbot_add_admin_menu() {
    add_options_page('Bebias Chatbot Settings', 'Bebias Chatbot', 'manage_options', 'bebias_chatbot', 'bebias_chatbot_options_page');
}
add_action('admin_menu', 'bebias_chatbot_add_admin_menu');

/**
 * Display the settings page
 */
function bebias_chatbot_options_page() {
    ?>
    <div>
        <h1>Bebias Chatbot Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('bebias_chatbot_options');
            do_settings_sections('bebias_chatbot');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

/**
 * Register settings
 */
function bebias_chatbot_settings_init() {
    register_setting('bebias_chatbot_options', 'bebias_chatbot_options');

    add_settings_section(
        'bebias_chatbot_section',
        __('Widget Settings', 'bebias-chatbot'),
        null,
        'bebias_chatbot'
    );

    add_settings_field(
        'widget_url',
        __('Widget URL', 'bebias-chatbot'),
        'bebias_chatbot_widget_url_render',
        'bebias_chatbot',
        'bebias_chatbot_section'
    );
}
add_action('admin_init', 'bebias_chatbot_settings_init');

/**
 * Render the widget URL field
 */
function bebias_chatbot_widget_url_render() {
    $options = get_option('bebias_chatbot_options');
    ?>
    <input type='text' name='bebias_chatbot_options[widget_url]' value='<?php echo $options['widget_url']; ?>'>
    <?php
}
function bebias_chatbot_enqueue_scripts() {
    wp_enqueue_style('bebias-chat-css', plugin_dir_url(__FILE__) . 'css/bebias-chat.css');
    wp_enqueue_style('bebias-chat-css', plugin_dir_url(__FILE__) . 'css/bebias-chat.css');
    wp_enqueue_script('bebias-chat-js', plugin_dir_url(__FILE__) . 'js/bebias-chat.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'bebias_chatbot_enqueue_scripts');

// Shortcode to display the chat widget
function bebias_chatbot_shortcode($atts) {
    $atts = shortcode_atts(array(
        'width' => '420',
        'height' => '600',
    ), $atts);

    ob_start();
    ?>
    <div id="bebias-chat-widget" style="width: <?php echo esc_attr($atts['width']); ?>px; height: <?php echo esc_attr($atts['height']); ?>px;">
        <client-chat-widget></client-chat-widget>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('bebias_widget', 'bebias_chatbot_shortcode');
?>
