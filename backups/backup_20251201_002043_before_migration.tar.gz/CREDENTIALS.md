# Bebias Chatbot Credentials

**IMPORTANT: Keep this file secure and never commit to Git!**

## Cloud Function Environment Variables (SET ✅)

### Email (Gmail SMTP)
- **EMAIL_USER**: `info.bebias@gmail.com`
- **EMAIL_PASSWORD**: `vehd woms sopo ohms` (Gmail App Password)

### Facebook Messenger
- **PAGE_ACCESS_TOKEN**: `EAAL9sPOK4AoBPZCAedC6Pnk6MO3kJynAfgGpOkgrjUKlOjr6rHsYYvnefBQW8G7yoLk9fJ7GZANew43ZBRb9PFLhQG5cl2FkxDDWZAbhWr34P7JnmW9CZAiCeZAeyCtWQDDoPWuOgKZAZALjhqbO55FqzRjyPyO3nsZCZBZBSv41jL7A1wBYIOJ9IEUDZCiqwupmDBYxyHhHnHQiFMQLZBIkxvZBRiEQZDZD`

### Vercel KV (Upstash Redis)
- **KV_REST_API_URL**: `https://intimate-rattler-22686.upstash.io`
- **KV_REST_API_TOKEN**: `AVieAAIncDJkMWQ1ZWEzNWZmYWE0NTc4YTEyZTliMjdmZGMzZjk5MXAyMjI2ODY`

### API Endpoints
- **NEXT_PUBLIC_CHAT_API_BASE**: `https://bebias-venera-chatbot.vercel.app`

### Firestore (Google Cloud)
- **GOOGLE_CLOUD_PROJECT_ID**: `bebias-wp-db-handler`
- **GOOGLE_CLOUD_CLIENT_EMAIL**: `bebias-chatbot-firestore@bebias-wp-db-handler.iam.gserviceaccount.com`
- **GOOGLE_CLOUD_PRIVATE_KEY**: (See firestore-key.json)

---

## Cloud Function URL
- **Payment Verifier**: `https://us-central1-bebias-wp-db-handler.cloudfunctions.net/verifyPayment`

---

## Updating Credentials

### Update Cloud Function:
```bash
cd cloud-functions/payment-verifier

gcloud functions deploy verifyPayment \
  --gen2 \
  --region=us-central1 \
  --update-env-vars="PAGE_ACCESS_TOKEN=your-token,EMAIL_USER=your-email,EMAIL_PASSWORD=your-app-password"
```

### Update Vercel:
```bash
vercel env add PAGE_ACCESS_TOKEN production
# Paste token when prompted
```

---

## Notes
- Gmail App Password created at: https://myaccount.google.com/apppasswords
- Facebook token may need periodic renewal
- KV credentials from Vercel dashboard
