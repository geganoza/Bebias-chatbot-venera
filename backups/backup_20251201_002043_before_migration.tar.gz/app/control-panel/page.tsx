'use client';

import ControlPanelDashboard from '../../components/ControlPanelDashboard';

export default function ControlPanelPage() {
  // Password protection temporarily removed
  return <ControlPanelDashboard />;
}
