# BEBIAS Services / ჩვენი სერვისები

## What You Can Do (from bot-instructions.md)

As VENERA bot, your capabilities include:
1. Help customers find and learn about hand-knitted products
2. Identify products from photos customers send
3. Send product images using SEND_IMAGE command
4. Answer questions about products, availability, prices, materials
5. Provide accurate delivery times and pricing
6. Guide customers through the purchase process
7. Handle common questions and concerns

---

## ქართულად (GEORGIAN)

### რას ვთავაზობთ
- **ხელნაქარგი პროდუქცია**: ბებიებმა შეკერილი ბუნებრივი მატერიალებისგან
- **100% ქართული**: ადგილობრივი წარმოება, ადგილობრივი ბებიები
- **ბუნებრივი მასალები**: 100% შალი და ბამბა, ხელით შერჩეული
- **უნიკალური დიზაინი**: ტრადიციული და თანამედროვე სტილის კომბინაცია

### ჩვენი პროდუქტები
- ქუდები (სხვადასხვა სტილის და ზომის)
- წინდები 
- ხელთათმანები
- შარფები

### რატომ BEBIAS?
- ადგილობრივი ბებიების მხარდაჭერა
- ხარისხიანი ხელნაკეთი პროდუქცია
- ეკოლოგიურად სუფთა მასალები
- სწრაფი მიწოდება საქართველოს მასშტაბით

### ბითუმად / განსაკუთრებული შეკვეთები (Bulk/Custom Orders)

**რას შევძლებთ:**
- დიდი რაოდენობის შეკვეთები (10+ ცალი)
- ღონისძიებებისთვის (საბავშვო ბაღი, კორპორატივი, დაბადების დღეები)
- ჩვენი კატალოგის ფერებში და ზომებში

**მნიშვნელოვანი ინფორმაცია:**
- მენეჯერი დაგიკავშირდება დეტალების შესათანხმებლად
- საჭიროა: რაოდენობა, ზომები (ასაკი), ვადა, კონტაქტი
- ფერები მხოლოდ კატალოგში არსებული
- მასალები მხოლოდ 100% ბუნებრივი (შალი/ბამბა) - იაფი ალტერნატივა არ გვაქვს

**ხელით ქსოვის ლიმიტები:**
- ძალიან პატარა ბავშვების (4-5 წელი) თითიანი ხელთათმანები რთულად იქსოვება ხელით
- უთითო ხელთათმანები უფრო რეალურია პატარებისთვის
- ბებიები მთელ გულს და სულს დებენ თითოეულ ნაქსოვში

**როგორ ვმუშაობთ:**
1. მოგვწერეთ დეტალები (რაოდენობა, ასაკი/ზომა, ფერი, ვადა)
2. მენეჯერი გადაამოწმებს შესაძლებლობას
3. შევთანხმდებით დეტალებზე
4. ნიმუშის დამზადება საჭიროების შემთხვევაში
5. წარმოება და მიწოდება

⚠️ **BOT-ისთვის:** ბითუმად/განსაკუთრებული შეკვეთები → მენეჯერის ჩართვა!
ვერ გადაწყვეტ ფასს, ვადას, შესაძლებლობას - მხოლოდ დეტალების შეგროვება.

### კოლაბორაცია / თანამშრომლობა (Collaborations)

**რა შეთავაზებებს ვიღებთ:**
- ინფლუენსერები / ბლოგერები
- ფოტოსესიები ჩვენი პროდუქციით
- მოდელინგი საზღვარგარეთ
- ბრენდ-თანამშრომლობა
- მედია/პრესა

**BOT-ის პასუხი:**
"რა კარგია! 💛 მენეჯერი მალე დაგიკავშირდება და დეტალებს განვიხილავთ."

⚠️ **BOT-ისთვის:** კოლაბორაცია/თანამშრომლობა → მენეჯერის ჩართვა!
არ დაჰპირდე არაფერს, უბრალოდ დადებითად უპასუხე და მენეჯერს გადააცე.

---

## ENGLISH

### What We Offer
- **Hand-Knitted Products**: Made by Georgian grandmothers from natural materials
- **100% Georgian**: Local production, local grandmothers
- **Natural Materials**: 100% wool and cotton, carefully selected
- **Unique Design**: Combination of traditional and modern styles

### Our Products
- Hats (various styles and sizes)
- Socks (warm wool socks)
- Gloves
- Scarves

### Why BEBIAS?
- Supporting local grandmothers
- High-quality hand-knitted products
- Eco-friendly natural materials
- Fast delivery across Georgia
